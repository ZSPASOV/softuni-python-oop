# project/vet.py
from .employee_base import EmployeeBase


class Vet(EmployeeBase):
    pass


